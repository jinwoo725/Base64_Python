A beginner's base64 encoder/decoder in Python

class Base64

-_encoding(type:string) > type:string
-_decoding(type:string) > type:string

Exam

-import base64_python
-base64 = base64_python.Base64()
-print(base64._encoding("test"))
-print(base64._decoding("dGVzdA=="))